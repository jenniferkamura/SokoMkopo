<?php include_once 'header.php'; ?>


<section class="appie-hero-area appie-hero-3-area">
    <div class="container">
        <div class="row  justify-content-center">
            <div class="col-lg-10">
                <div class="appie-hero-content text-center">
                    <h1 class="appie-title">peer-to-peer lending </h1>
                    <p>The purpose of the Sokomkopo app is to provide a platform for peer-to-peer lending, savings, and investment in the Kenyan market. The app will use a credit scoring engine to determine the risk level of borrowers based on their savings history. The app will be designed to be user-friendly and accessible to a wide range of users.</p>
                    <div class="hero-btns">
                        <a class="main-btn" href="#">Get a Quote</a>
                        <a class="appie-video-popup" href="#"><i class="fas fa-play"></i> Play Video</a>
                    </div>
                    <div class="thumb mt-100 wow animated fadeInUp" data-wow-duration="2000ms" data-wow-delay="400ms">
                        <img src="assets/images/hero-thumb-4.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!--====== APPIE HERO PART ENDS ======-->

<!--====== APPIE SERVICES PART START ======-->

<section class="appie-service-area appie-service-3-area pt-195 pb-100" id="service">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="appie-section-title text-center">
                    <h3 class="appie-title">What you can do</h3>
                    <p>The full monty spiffing good time no biggie cack grub fantastic. </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="appie-single-service appie-single-services-3 text-center mt-30 wow animated fadeInUp" data-wow-duration="2000ms" data-wow-delay="200ms">
                    <div class="icon">
                        <img src="assets/images/icon/1.png" alt="">
                    </div>
                    <h4 class="appie-title">Easy to use</h4>
                    <p>Mucker plastered bugger all mate morish are.</p>
                    <a href="#">Read More <i class="fal fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="appie-single-service appie-single-services-3 text-center mt-30 item-2 wow animated fadeInUp" data-wow-duration="2000ms" data-wow-delay="400ms">
                    <div class="icon">
                        <img src="assets/images/icon/2.png" alt="">
                    </div>
                    <h4 class="appie-title">App Development</h4>
                    <p>Mucker plastered bugger all mate morish are.</p>
                    <a href="#">Read More <i class="fal fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="appie-single-service appie-single-services-3 text-center mt-30 item-3 wow animated fadeInUp" data-wow-duration="2000ms" data-wow-delay="600ms">
                    <div class="icon">
                        <img src="assets/images/icon/3.png" alt="">
                    </div>
                    <h4 class="appie-title">Fully Functional</h4>
                    <p>Mucker plastered bugger all mate morish are.</p>
                    <a href="#">Read More <i class="fal fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="appie-single-service appie-single-services-3 text-center mt-30 item-4 wow animated fadeInUp" data-wow-duration="2000ms" data-wow-delay="800ms">
                    <div class="icon">
                        <img src="assets/images/icon/4.png" alt="">
                    </div>
                    <h4 class="appie-title">Secured protocol</h4>
                    <p>Mucker plastered bugger all mate morish are.</p>
                    <a href="#">Read More <i class="fal fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>

<!--====== APPIE SERVICES PART ENDS ======-->

<!--====== APPIE FUN FACT PART START ======-->

<section class="appie-fun-fact-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="appie-fun-fact-box wow animated fadeInUp" data-wow-duration="2000ms" data-wow-delay="400ms">
                    <div class="row r">
                        <div class="col-lg-6">
                            <div class="appie-fun-fact-content">
                                <h3 class="title">Get started with Appie Template.</h3>
                                <p>The app provides design and digital marketing, applied arts can include industrial design</p>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="appie-fun-fact-item">
                                            <h4 class="title">700k</h4>
                                            <span>App Downloads</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="appie-fun-fact-item">
                                            <h4 class="title">476+</h4>
                                            <span>Average Review</span>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="appie-fun-fact-item">
                                            <h4 class="title">30M</h4>
                                            <span>Active Users</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="appie-fun-fact-play">
                                <a class="appie-video-popup" href="https://www.youtube.com/watch?v=EE7NqzhMDms"><i class="fas fa-play"></i></a>
                                <img src="assets/images/fun-fact-thumb.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!--====== APPIE FUN FACT PART ENDS ======-->

<!--====== APPIE ABOUT 3 PART START ======-->

<section class="appie-about-3-area pt-100 pb-100" id="features">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="appie-about-thumb-3 wow animated fadeInLeft" data-wow-duration="2000ms" data-wow-delay="400ms">
                    <img src="assets/images/about-thumb-2.png" alt="">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="appie-traffic-title">
                    <h3 class="title">Appie lets you launch your app in minutes.</h3>
                    <p>He nicked it tickety boo harry the cras bargy chap mush spiffing spend a penny the full monty burke butty.</p>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="appie-traffic-service mb-30">
                            <div class="icon">
                                <img src="assets/images/icon/5.svg" alt="">
                            </div>
                            <h5 class="title">Carefully designed</h5>
                            <p>Mucker plastered bugger all mate morish are.</p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="appie-traffic-service item-2 mb-30">
                            <div class="icon">
                                <img src="assets/images/icon/1.png" alt="">
                            </div>
                            <h5 class="title">Seamless Sync</h5>
                            <p>Mucker plastered bugger all mate morish are.</p>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="traffic-btn mt-50">
                            <a class="main-btn" href="#">Learn More <i class="fal fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row align-items-center mt-100  flex-column-reverse flex-lg-row">
            <div class="col-lg-6">
                <div class="appie-traffic-title">
                    <h3 class="title">Browse over 40k Apps over the world</h3>
                    <p>He nicked it tickety boo harry the cras bargy chap mush spiffing spend a penny the full monty burke butty.</p>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="appie-traffic-service mb-30 item-3">
                            <div class="icon">
                                <img src="assets/images/icon/6.svg" alt="">
                            </div>
                            <h5 class="title">User Interactive</h5>
                            <p>Mucker plastered bugger all mate morish are.</p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="appie-traffic-service item-2 mb-30 item-4">
                            <div class="icon">
                                <img src="assets/images/icon/7.svg" alt="">
                            </div>
                            <h5 class="title">Choose a App</h5>
                            <p>Mucker plastered bugger all mate morish are.</p>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="traffic-btn mt-50">
                            <a class="main-btn" href="#">Learn More <i class="fal fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="appie-about-thumb-3 text-right wow animated fadeInRight" data-wow-duration="2000ms" data-wow-delay="400ms">
                    <img src="assets/images/about-thumb-3.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>

<!--====== APPIE ABOUT 3 PART ENDS ======-->

<!--====== APPIE SHOWCASE PART START ======-->

<section class="appie-showcase-area ">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="appie-section-title text-center">
                    <h3 class="appie-title">Creative app showcase</h3>
                    <p>The app provides design and digital marketing.</p>
                </div>
            </div>
        </div>
        <div class="row appie-showcase-slider">
            <div class="col-lg-3">
                <div class="appie-showcase-item mt-30">
                    <a class="appie-image-popup" href="assets/images/showcase-1.png"><img src="assets/images/showcase-1.png" alt=""></a>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="appie-showcase-item mt-30">
                    <a class="appie-image-popup" href="assets/images/showcase-2.png"><img src="assets/images/showcase-2.png" alt=""></a>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="appie-showcase-item mt-30">
                    <a class="appie-image-popup" href="assets/images/showcase-3.png"><img src="assets/images/showcase-3.png" alt=""></a>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="appie-showcase-item mt-30">
                    <a class="appie-image-popup" href="assets/images/showcase-4.png"><img src="assets/images/showcase-4.png" alt=""></a>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="appie-showcase-item mt-30">
                    <a class="appie-image-popup" href="assets/images/showcase-2.png"><img src="assets/images/showcase-2.png" alt=""></a>
                </div>
            </div>
        </div>
    </div>
    <div class="showcase-shape-1">
        <img src="assets/images/shape/shape-14.png" alt="">
    </div>
    <div class="showcase-shape-2">
        <img src="assets/images/shape/shape-13.png" alt="">
    </div>
    <div class="showcase-shape-3">
        <img src="assets/images/shape/shape-12.png" alt="">
    </div>
    <div class="showcase-shape-4">
        <img src="assets/images/shape/shape-15.png" alt="">
    </div>
</section>

<!--====== APPIE SHOWCASE PART ENDS ======-->

<!--====== APPIE DOWNLOAD 3 PART START ======-->

<section class="appie-download-3-area pt-100" id="download">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="appie-section-title text-center">
                    <h3 class="appie-title">Download app today!</h3>
                    <p>Download app for Andraoid today — it's free.</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="appie-download-3-box mt-30 mr-20 wow animated fadeInLeft" data-wow-duration="2000ms" data-wow-delay="200ms">
                    <div class="content">
                        <h4 class="title">Android</h4>
                        <p>Download app for Android today — it's free.</p>
                        <a class="main-btn" href="#"><i class="fab fa-google-play"></i>Download for Android</a>
                    </div>
                    <div class="thumb text-center">
                        <img src="assets/images/download-thumb-1.png" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="appie-download-3-box mt-30 ml-20 wow animated fadeInRight" data-wow-duration="2000ms" data-wow-delay="400ms">
                    <div class="content">
                        <h4 class="title">iOS & iPadOS</h4>
                        <p>Download app for iOS today — it's free.</p>
                        <a class="main-btn main-btn-2" href="#"><i class="fab fa-apple"></i>Download for iOS</a>
                    </div>
                    <div class="thumb text-right">
                        <img src="assets/images/download-thumb-2.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!--====== APPIE DOWNLOAD 3 PART ENDS ======-->

<!--====== APPIE BLOG 3 PART START ======-->

<section class="appie-blog-3-area pt-90 pb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="appie-section-title text-center">
                    <h3 class="appie-title">Latest blog posts</h3>
                    <p>The app provides design and digital marketing.</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="appie-blog-item-3 mt-30">
                    <div class="thumb">
                        <img src="assets/images/blog-4.jpg" alt="">
                    </div>
                    <div class="content">
                        <h5 class="title"><a href="#">How to Improve Your App Store Position</a></h5>
                        <div class="meta-item">
                            <ul>
                                <li><i class="fal fa-clock"></i> July 14, 2022</li>
                                <li><i class="fal fa-comments"></i> July 14, 2022</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="appie-blog-item-3 mt-30">
                    <div class="thumb">
                        <img src="assets/images/blog-5.jpg" alt="">
                    </div>
                    <div class="content">
                        <h5 class="title"><a href="#">Introducing New App Design for our iOS App</a></h5>
                        <div class="meta-item">
                            <ul>
                                <li><i class="fal fa-clock"></i> July 14, 2022</li>
                                <li><i class="fal fa-comments"></i> July 14, 2022</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="appie-blog-item-3 mt-30">
                    <div class="thumb">
                        <img src="assets/images/blog-6.jpg" alt="">
                    </div>
                    <div class="content">
                        <h5 class="title"><a href="#">Engineering job is Becoming More interesting.</a></h5>
                        <div class="meta-item">
                            <ul>
                                <li><i class="fal fa-clock"></i> July 14, 2022</li>
                                <li><i class="fal fa-comments"></i> July 14, 2022</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="appie-blog-item-3 mt-30">
                    <div class="thumb">
                        <img src="assets/images/blog-7.jpg" alt="">
                    </div>
                    <div class="content">
                        <h5 class="title"><a href="#">20 Myths About Mobile Applications</a></h5>
                        <div class="meta-item">
                            <ul>
                                <li><i class="fal fa-clock"></i> July 14, 2022</li>
                                <li><i class="fal fa-comments"></i> July 14, 2022</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="blog-btn text-center mt-60">
                    <a class="main-btn" href="#">View All Posts <i class="fal fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>

<!--====== APPIE BLOG 3 PART ENDS ======-->

<!--====== APPIE PROJECT 3 PART START ======-->

<section class="appie-project-3-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="appie-project-3-box d-block d-md-flex justify-content-between align-items-center wow animated fadeInUp" data-wow-duration="2000ms" data-wow-delay="400ms">
                    <h4 class="title">Start your project <br> with Appie.</h4>
                    <a class="main-btn" href="#">Let’s Talk</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!--====== APPIE PROJECT 3 PART ENDS ======-->


<?php include_once 'footer.php'; ?>